# Hỏi đáp paper qua NotebookLM — Linnhoff et al. 2212.08558

Nguồn: notebook `Mô Phỏng Hiệu Ứng Bụi Nước Trên Cảm Biến Lidar Ô Tô`
(id `f2c09ee8-1c5c-45d3-869d-e62559073f1c`), source duy nhất là PDF arXiv
2212.08558. Câu hỏi soạn theo 5 nhóm, chỉ thị bắt buộc trả lời nguyên văn +
số hiệu mục/hình, và trả lời đúng chữ `NOT STATED IN PAPER` khi paper không nói.

Mục đích: tách **cái paper thật sự nói** khỏi **cái code tham chiếu
(`dee.cpp`) tự đặt**, để mọi tham số của generator v2 có nguồn rõ ràng.

---

## 1. Vùng đặt cụm (spray region)

| Câu hỏi | Kết quả | Trích dẫn / vị trí |
|---|---|---|
| Kích thước vùng có trong paper? | **KHÔNG** | §III-B: chỉ nói "region behind every moving object" |
| Điểm neo? | Không nêu cản sau/tâm/cảm biến, nhưng có ràng buộc mạnh hơn | *"The initialization of clusters is restricted to the vehicle trajectory and no clusters are spawned randomly in the scene."* (§III) |
| Chiều cao / độ cao thẳng đứng? | **KHÔNG** | `NOT STATED IN PAPER`; §V chỉ nói cần nghiên cứu thêm lốp và tải |
| Chiều rộng 3,4 m, dài `v·Δt`? | **KHÔNG** | chỉ có trong `dee.cpp:559-561` |
| Ai sinh spray? | **ego + mọi vật thể di chuyển** | *"The model requires knowledge of the trajectories of the ego vehicle and all surrounding vehicles that cause spray."* (§III-3); *"spray clusters are generated for each individual moving object in the scene, there is no interaction"* (§V) |

Fig. 3b: hộp nét đứt nhãn "Spray detection filter region", vẽ **sau** xe Object,
dài cỡ 2–3 lần chiều dài xe, **không vẽ theo tỉ lệ**, không kèm số đo.

## 2. Xoá cụm / vòng đời

| Câu hỏi | Kết quả |
|---|---|
| Quy tắc xoá cụm theo tuổi/quãng đường/ra khỏi vùng | **KHÔNG có trong paper** |
| Ngưỡng `4T` | **KHÔNG có trong paper** — chỉ có ở `dee.cpp:445-450` |
| Nói gì về cụm ở sau cảm biến ego / cụm mà ego đã vượt qua | **KHÔNG có** |
| Giới hạn khoảng cách sinh detection | **KHÔNG có**; chỉ có phạm vi **đánh giá** 0–50 m (*"the test set is labeled up to 50 m"*) |

Hệ quả: "vệt plume dài" **không mâu thuẫn paper** — paper không đặt luật cắt nào.
Mọi ngưỡng cắt là quyết định của mình, phải khai báo là `[CHỌN]`.

## 3. `P_det`, eq. (7)

Trích nguyên văn: *"A beam generates only a detection in a certain cluster with a
detection probability given as `P_det = n / n_max(r_cl, p_cl)`, with the number of
detections `n` in a given cluster and the number of beams `n_max(r_cl, p_cl)`
intersecting the spherical representation of the cluster. The maximum number of
possible detections in a spherical cluster representation depends on the cluster
radius and the cluster position with respect to the beam pattern of the sensor."*

- `n` = số detection **đo được** trong cụm; `n_max` = số **tia cắt** khối cầu ⇒ **hình học**, tính được.
- `P_det` là tỉ lệ theo **cặp (tia, cụm)**: mỗi tia cắt cụm bốc Bernoulli với xác suất đó.
- Phương sai giữa các cụm đến từ **Fig. 7**: lognormal `µ = −2,3 σ = 1,09` (trung bình `e^{µ+σ²/2} ≈ 0,18`) — bốc **một lần cho mỗi cụm**, rồi áp lên từng tia.
- Kết hợp thời gian: *"As the cluster dissolves, the detection probability decreases by the time factor T introduced in equation (1)."* ⇒ `P_eff = P_det · P_t`.
- Range: *"the range is set to a normal distribution around the middle of the cluster"*.
- Intensity: *"the final intensity value of the simulated spray detections are set to 0"*; `N(0,5; 0,05)` chỉ để **so sánh giữa nhiều detection trong một tia**.

## 4. Số cụm, WFH, tham số

- Số cụm là hàm của **tốc độ vật thể** (không phải ego), class, và `wfh`: *"the number of clusters that are generated in each simulation time step are calculated as a function of the object speed, class, and water film height."*
- Cách đếm: đếm cụm thật trong "spray filter region" của **dữ liệu đo** ở khoảng cách vật thể **25 m**, rồi chia cho **tỉ lệ chiều dài vùng / quãng đường vật thể đi trong một scan**. Không có công thức in rời trong paper.
- `wfh` calibration: 0,5 / 0,75 / 1,0 mm. Augmentation: *"the water level is sampled from an **exponential distribution** from the interval 0.1 − 1.2 mm during training."*
- Augmentation **chỉ áp lên mẫu có ego-velocity > 60 km/h**.
- Cảm biến: Velodyne VLP32 trên nóc xe đo; DBSCAN `minPts = 3`, neighborhood `0,7°`, elevation discretisation `0,333°`.

## 5. Giao thức đánh giá — chống leakage

- **Ba bộ dữ liệu tách rời:** (1) calibration set có spray cô lập, vật thể ở 25 m → khớp tham số mô hình; (2) **training trên SeeingThroughFog (STF)**; (3) **spray test set riêng 1.463 frame**, 6 kịch bản (Table I: G-Class 79,9; Smart 118,3; CLA 97,4; Smart 97,6; CLA 121,0; CLA+2×G-Class 96,2 km/h), nhãn tới 50 m.
- *"To evaluate the model, object distances and values, which were not utilized for the model calibration, are used on the same data set."*
- Metric: KITTI eval, **AP tại 40 điểm recall**, chia dải 0–30 m và 30–50 m; detector PV-RCNN và Voxel-RCNN (OpenPCDet).
- Mô hình được đánh giá lại trên **clear-weather test set** của STF.

⇒ Paper **không** calibrate trên chính tập eval. Bản port của mình phải giữ đúng
nguyên tắc đó: tham số đo trên **train scenes**, eval trên **scene giữ riêng**.

## 6. Hạn chế tác giả tự nêu (dùng cho Limitations của luận văn)

1. Đặt cụm theo uniform là *"a first estimate"*, chưa kiểm chứng phân bố thật.
2. Gió giả định giống nhau cho mọi cụm, bỏ qua gió giật.
3. Cụm chồng lấp **không bị cấm** trong mô hình.
4. **Biểu diễn khối cầu ở khoảng cách gần: "can become especially pronounced in close proximity to the sensor"** ⇒ đúng vùng plume thật của mình (range median 3,8–9,1 m).
5. Chỉ mô hình **một echo** (single echo).
6. Không mô hình vật cản không sinh detection (gương, vật tối) ⇒ spray vẫn sinh điểm phía sau chúng.
7. Chưa có tương tác giữa các xe; mới có 2 loại vật thể; lốp và tải chưa được khảo sát.
8. Chạy tuần tự trên CPU Intel i9, không tăng tốc.

## 7. Việc mình phải tự quyết (paper không cho)

| Tham số | Trạng thái | Cách xử |
|---|---|---|
| Chiều cao vùng đặt cụm | paper NOT STATED, code `1,5 m` | đo nhãn thật: p5 0,16 / med **1,51** / p95 **2,36 m** trên mặt đường = 6 / 58 / 90 % chiều cao box 2,62 m ⇒ dùng `0,87 × chiều cao vật thể`, đáy = mặt đường + `0,05 × h` |
| Chiều rộng vùng | paper NOT STATED, code `3,4 m` | giữ, hợp lệ với `|y|` p95 thật 2,31 m; khai báo `[CODE]` |
| Chiều dài vùng | paper NOT STATED, code `v·Δt` | giữ `[CODE]` |
| Xoá cụm | paper NOT STATED, code `age > 4T` | giữ `4T` `[CODE]`, **không** thêm ngưỡng mét |
| Cụm sau cảm biến (62–93 % nhãn thật) | paper NOT STATED; paper có nói **ego cũng là nguồn spray** | quyết định: có sinh spray sau ego hay không |

## 8. Bổ sung 2026-11-11 — hỏi lại notebook cho ticket 29d/29c

Hỏi qua CLI `notebooklm -p phk4` (Edge cookies, tài khoản `huynguyen.phk4@gmail.com` — tài khoản này
là **owner** của notebook; profile `default` của `huy7a2004@gmail.com` đã hết hạn token).

### 8.1 Recipe đếm cụm — §III-B, trích nguyên văn

| Điều | Nguyên văn |
|---|---|
| Thuật toán | *"To quantify this effect, a DBSCAN algorithm is applied to the detections."* |
| Không gian | *"The DBSCAN algorithm is applied to the point cloud in spherical coordinates to account for the change in Cartesian resolution over distance."* |
| Lân cận | *"To ensure possible clustering in vertical direction, the search neighborhood of DBSCAN is set to 0.7° to cover at least two scan lines of the sensor."* |
| `minPts` | *"As small clusters are observed in the recorded data, three points is defined as the minimum number of points that can form a cluster."* |
| Độ phân giải góc | *"In the central elevation field of view, the Velodyne VLP32 has an elevation angle discretization of 0.333°."* |
| Hộp hay tròn trong mặt phẳng góc | **NOT STATED IN PAPER** |
| Lân cận có ràng buộc cả khoảng cách `r` | **NOT STATED IN PAPER** |

⇒ Toán tử của mình: DBSCAN trên `(azimuth, elevation)`, `eps = 0,7°` Euclid, elevation snap lưới
`0,333°`, `minPts = 3`, azimuth wrap modulo 360. Hai chỗ paper không nói ⇒ `[CHỌN]`.
**Toán tử `0,5 m` Euclid của `spray/spray_stats.py` KHÔNG phải recipe paper** — vẫn dùng được như số cũ
để so, nhưng không được gọi là "khớp paper".

### 8.2 Số neo để so (Fig. 1 text box, Fig. 11) — [PAPER]

| Đại lượng | Giá trị | Nguồn |
|---|---|---|
| Cụm/frame, Crafter 50 m, **100 km/h** | **33** cụm | Fig. 1 text box |
| Detections/cụm (trung bình) | **14,3** | Fig. 1 text box |
| Clustered/total | **84,1 %** | Fig. 1 text box |
| Cụm/frame @130 km/h, mặt đường ướt đẫm | **~75** đo, **~110** mô phỏng | Fig. 11b |
| Bán kính cụm `r_cl` | lognormal `µ = −1,2`, `σ = 0,8` ⇒ median **0,30 m**, mean **0,42 m** | Fig. 5, §III-B |

⚠️ **Mâu thuẫn phải sửa**: `docs/measurements/semantic-spray-stats.md` ghi **17,06 cụm/frame** và ticket 31
đang lấy số đó làm mốc "khớp Fig. 11a". Paper nói **33** cụm ở 100 km/h và **~75** ở 130 km/h. Con số
17,06 sinh ra bởi single-linkage `0,5 m` + `dense_min = 5` ⇒ đếm thiếu. Ticket 31 **không** được dùng
`17,06` làm mốc cho tới khi đo lại bằng toán tử §8.1.

### 8.3 Protocol chia dữ liệu — paper KHÔNG chia scene

| Điều | Nguyên văn |
|---|---|
| Hiệu chỉnh vs đánh giá | *"The disturbance is analyzed and modeled by clustering of the point cloud in a first data set with isolated spray effects and the overall model validation is performed using object detection algorithms on a second data set."* (§II) |
| Cách "held-out" của paper | *"To evaluate the model, object distances and values, which were not utilized for the model calibration, are used on the same data set. This is done to evaluate and verify the model and its calibration."* (§IV-1) |
| Tập kiểm thử riêng | *"the effectiveness of the spray augmentation is evaluated on a dedicated spray test set."* (§III-3) |

⇒ Paper **giữ lại điều kiện** (khoảng cách/giá trị chưa dùng khi hiệu chỉnh) **trên cùng bộ dữ liệu**,
không chia scene 1:1. Split `cal`/`held-out` của ticket 29d là quyết định riêng của mình ⇒ `[CHỌN]`,
không được trình bày như protocol của paper. Hệ quả: khi viết báo cáo, nêu rõ hai khác biệt
(1) paper giữ điều kiện, mình giữ scene; (2) paper có bộ dữ liệu thứ hai 1.463 frame, mình không có.

### 8.4 Hình học vùng spray — vẫn NOT STATED

Hỏi lại lần này: **chiều cao trên mặt đường, bề rộng ngang, chiều dài sau vật thể** — cả ba đều
**NOT STATED IN PAPER**. Fig. 1 chỉ vẽ trục `z in m` từ −2 đến 2 m, không có số đo; Fig. 3b là hộp
schematic, không có kích thước. Fig. 5 chỉ cho **bán kính cụm** (`r_cl` = khoảng cách xa nhất từ
detection tới tâm cụm), không cho kích thước vùng.

⇒ Nhãn đúng cho các giá trị đang dùng: `5–92 %` chiều cao box và `3,4 m` bề rộng là **`[ĐO]` trên
939.803 điểm nhãn thật + `[CHỌN]` khi quy ra tham số box** — **không** phải giá trị paper. Chỉ
`intensity = 0` và `P_det = n / n_max` là `[PAPER]`.

## 9. Bổ sung 2026-11-11 (đợt 2) — tuổi thọ cụm, tắt tín hiệu, số cụm theo tốc độ

### 9.1 Tuổi thọ cụm — §III-B, eq. (1)

> *"Clusters do not just disappear after a certain amount of time, but they dissolve gradually. This
> behavior is modeled by changing the detection probability of the clusters exponentially over time
> with a probability factor based on an exponential impulse response"* → `P_t(t) = exp(−t/T)`
>
> *"the time constant T is defined as the time required to reduce the detection count to 36 % of the
> maximum"*
>
> *"From Fig. 6, it becomes apparent that the time constants rise with respect to object speed, which
> is approximated by linear functions for the different watering levels."*
>
> *"The only differences between the two vehicles are the number of clusters and the dissolve time
> constant. These are set separately for the object classes."*

`T` theo Fig. 6 đọc được: `≈0,15–0,25 s` @50 km/h → `1,15 s` (ẩm) / `1,4 s` (phủ một phần) /
`1,8 s` (ướt đẫm) @130 km/h. **Ngưỡng xoá cứng: NOT STATED** ⇒ `age > 4T` vẫn là `[CODE]`.

✅ Code hiện tại: `T = 0,02·wfh·(v−50) + 0,2` cho `0,20 / 1,00 / 1,80 s` tại `50 / 130 ẩm / 130 ướt
đẫm` — **khớp paper**, không phải sửa.

### 9.2 Tắt tín hiệu do spray — §III-B "Attenuation"

> *"Since a beam intersecting with a cluster generates only a detection with a certain detection
> probability, a beam can pass multiple clusters, before generating a detection. As water in the air
> not only reflects light back to the sensor but also scatters the light, an attenuation occurs."*
>
> *"The total distance a beam traveled through multiple clusters is calculated and an attenuation is
> applied. … yields a mean extinction coefficient of **0.02 m⁻¹**."*
>
> *"If a detection existed in a beam before the spray simulation, the attenuation due to the spray is
> also applied to its intensity. In the end, the detection intensities of all detections from a beam
> are compared and the strongest is added to the overall point cloud."*

⇒ Paper **có** mô hình tắt tín hiệu thật, và giữ **một** return mạnh nhất mỗi tia. Code có
`mean_attenuation_per_m = 0,02` ✓ nhưng dùng `exp(−2·σ·L)` (khứ hồi, `[CODE]`); paper **chỉ in ra
σ**, không in dạng mũ ⇒ `NOT STATED IN PAPER`, giữ `2` và khai `[CODE]`.

### 9.3 Số cụm theo tốc độ — Fig. 11b (đọc xấp xỉ trên đồ thị, `[PAPER-graph]`)

| km/h | 70 | 80 | 90 | 100 | 110 | 120 | 130 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Ướt đẫm (1,0 mm) | 4,5 | 21 | 28,5 | 43 | 49,5 | 56,5 | **74,5** |
| Ẩm (0,5 mm) | 3,5 | 10,5 | 23,5 | 29,5 | 31 | 32,5 | **41,5** |

(Fig. 1 text box cho một frame đơn @100 km/h: **33** cụm — khác Fig. 11b vì 11b là trung bình nhiều
frame; dùng 11b để hiệu chỉnh, 1 để sanity-check bậc độ lớn.)

Quy tắc của paper, §III-B nguyên văn:

> *"The number of clusters generated within one simulation time step is determined by first counting
> the number of clusters in a spray filter region behind the vehicle. This total number is then
> divided by the length ratio of the spray region to the distance the object traveled during one scan
> of the sensor."*

Suy ngược bằng `K(T) = Σ_{k=0}^{4T/Δt} exp(−k·Δt/T)` của chính code (`plume.py`):

| km/h | K (ướt đẫm) | cụm/chu kỳ suy ra | code hiện tại | K (ẩm) | cụm/chu kỳ suy ra | code hiện tại |
|---:|---:|---:|---:|---:|---:|---:|
| 80 | 8,37 | 2,5 | 9 | 5,43 | 1,9 | 6 |
| 100 | 12,28 | 3,5 | 15 | 7,37 | 4,0 | 10 |
| 130 | 18,18 | 4,1 | 24 | 10,33 | 4,0 | 16 |

⇒ Hai kết luận:

1. **Tốc độ sinh cụm hiện tại sai 4–6×** (`(0,2·wfh+0,1)·(v−50)` [CODE, dee.cpp] cho 24/chu kỳ ở
   130 km/h ướt đẫm, paper tương ứng **~4**).
2. **Độ ẩm gần như không đổi tốc độ sinh** (`3,5–4,1` ở mọi mức ẩm khi `v ≥ 100`); độ ẩm tác động
   qua **`T`** (cụm sống lâu hơn ⇒ thấy nhiều hơn). Nhân `(0,2·wfh+0,1)` vào tốc độ sinh là **sai
   chỗ**: nó vừa thừa 4–6×, vừa gán phụ thuộc ẩm vào sai biến.
3. Đường hiệu chỉnh đơn giản khớp bảng trên: `rate(v) = min(3,8 ; 0,107·(v−60))` cụm/chu kỳ, độc lập
   `wfh`; `visible = rate × K(T(wfh, v))`.
4. Hệ quả cấu trúc: 807–1.555 điểm/frame ÷ 436 cụm ≈ **2–3,5 det/cụm**, paper là **14,3** ⇒ đang tạo
   nhiều cụm nhỏ li ti thay vì ít cụm dày. Phải hiệu chỉnh `P_det` cùng lúc với số cụm.

### 9.4 Vị trí và phân bố của tâm cụm — §III, §III-B

> *"The initialization of clusters is restricted to the vehicle trajectory and no clusters are spawned
> randomly in the scene."*
>
> *"To simulate clusters, spheres are positioned with a **uniform distribution** in the region behind
> every moving object according to the empirical values for the number of clusters and the distribution
> of cluster radii."*
>
> *"A uniform distribution was chosen as a first estimate, as no other form of distribution was
> visible. Nevertheless, this will be evaluated in future work."*

| Thành phần | Paper | Ghi chú |
|---|---|---|
| Hình dạng phân bố | **đều** (uniform) trong vùng sau vật thể | `[PAPER]` |
| Bề rộng / lệch ngang | **NOT STATED** (không có số) | code `lateral_sigma_m = 0,5` **Gaussian** ⇒ sai hình dạng, và `p95(|lateral|) ≈ 0,98 m` so với số thật `2,31 m` |
| Khoảng cách sau đuôi | **NOT STATED** | code `distance_range_m` `[CODE]` |
| Độ cao tâm cụm | **NOT STATED** | code `height_range_m` `[CODE]` |
| Ràng buộc quỹ đạo | cụm chỉ sinh trên quỹ đạo vật thể, không rải ngẫu nhiên | code sinh quanh box, tương đương ✓ |

### 9.5 Số cụm theo lớp xe — chỉ Crafter được định lượng

> *"The demonstrated calibration on the example of the Crafter is performed the same way for the Golf
> vehicle. However, the parameters of cluster radius, detection probability and intensity stay within
> the variations within one vehicle class. The only differences between the two vehicles are the
> number of clusters and the dissolve time constant. These are set separately for the object classes."*
>
> Fig. 4 caption: *"Measured number of clusters generated by the VW Crafter during one scan."*
> Fig. 11 caption: *"…numbers of detections and numbers of clusters in the spray plume from a Crafter
> at 50 m distance"*

⇒ Mọi bảng số của paper (Fig. 4, Fig. 11b, 33 cụm/frame, 14,3 det/cụm, `T @130`) là của **Crafter**.
Số cho **Golf: NOT STATED**. Vì dataset của mình có cả `Golf_dynamic` (99 scene lận), tham số Golf
**phải tự đo** trên `cal` — không được suy từ Crafter rồi nhân hệ số tuỳ ý.

### 9.6 ĐÍNH CHÍNH 2026-11-11 (chiều): Fig. 11b KHÔNG dùng được làm đích hiệu chỉnh

Mục 9.1–9.3 ở trên suy ngược từ Fig. 11b (75 cụm/frame @130 km/h, 33 @100, 21 @80) ra tốc độ sinh
cụm mỗi chu kỳ. Đo lại chính dataset `cal` bằng đúng recipe paper cho kết quả khác:

| km/h | Crafter đo được | Fig. 11b |
|---:|---:|---:|
| 80 | 22,0 | 21 ✓ |
| 100 | **29,2** | 33 ✓ |
| 130 | **17,7** | 75 ✗ |

Fig. 11 caption ghi rõ *"…from a Crafter **at 50 m distance**"*, còn dataset chỉ có **20 m và 30 m**.
Cự ly xa cho **ít** cụm hơn (20 m nhiều hơn 30 m 10–20 %) nên ngoại suy 30 → 50 m chỉ làm số giảm,
không thể thành 75. Noise/frame cũng giảm ở tốc độ cao (1.545 @100 so với 890 @130), tức các scene
120–130 km/h của dataset nhẹ nước hơn figure.

⇒ Đích hiệu chỉnh là bảng đo `docs/measurements/semantic-spray-clusters-by-speed.md`, không phải
Fig. 11b. Số paper chỉ dùng làm **kiểm tra chéo** ở 100 km/h. Chi tiết: mục 7 của ticket 29c.

## 10. Hỏi ngày 2026-11-11 (chiều) — định nghĩa `n`, `n_max`, Fig. 5, Fig. 11a/11b

Nguồn: NotebookLM profile `phk4`, notebook `f2c09ee8-1c5c-45d3-869d-e62559073f1c`, PDF 2212.08558.

### 10.1 `n` và `n_max` trong `P_det = n / n_max`

- **`n` = số detection thực tế thuộc cụm trong frame** — nguyên văn *“the number of detections `n` in
  a given cluster”*.
- **`n_max` = số tia Lidar cắt qua khối cầu của cụm** — nguyên văn *“the number of beams
  `n_max(r_cl, p_cl)` intersecting the spherical representation of the cluster”*.
- ⇒ Code `spray/raycast.py` tính đúng cả hai; `Ω_tia = 0,19726° × 0,3333° = 2,003e−5 sr` là số tia
  trên một đơn vị góc, không phải hằng số paper — đó là `[CHỌN]` của mình, đã ghi rõ.

### 10.2 Paper báo mean hay chỉ lognormal?

- Mô hình: **không có mean cố định**; biến thiên `P_det` giữa các cụm fit **lognormal µ = −2,3,
  σ = 1,09** ⇒ mean `e^{−2,3+1,09²/2} = 0,18`.
- Số đo: **Fig. 1** (ví dụ 1 frame, Crafter 100 km/h, 50 m) ghi trong khung thông số
  `Num. Clusters: 33`, **`Mean Det./Cluster: 14.3`**, `Clustered/Total: 84.1 %`.
- ⇒ Khi so `det/cụm` phải so **cùng một thống kê và cùng điều kiện cự ly**. Con số 14,3 là
  frame-level ở 50 m; bảng `cal` của mình là **frame-level ở 20/30 m** với `p50 = 6`,
  `mean = 43,3` (100 km/h) — không mâu thuẫn, nhưng **không được trộn**.

### 10.3 Fig. 5 — phân bố bán kính cụm

- `r_cl` = *“maximum distance of detections to the respective cluster center”* (vì cụm xấp xỉ cầu).
- Fit **lognormal**, tham số ví dụ **µ = −1,2, σ = 0,8** ⇒ **median = e^{−1,2} = 0,30 m** `[PAPER]`.
- CDF Fig. 5 cắt 0,5 quanh `10^{−0,5} ≈ 0,3 m` — khớp.
- ⇒ Hằng số `r_cl` trong `spray/plume.py` **đã đúng paper**, không phải `[CHỌN]`, **không được
  hiệu chỉnh theo tốc độ**.

### 10.4 Hình dạng cụm và việc gộp cụm

- Cụm là **khối cầu độc lập**, đặt **uniform**; range của detection lấy theo **normal quanh tâm cụm**.
- Nguyên văn: *“With the independent uniform placement of clusters with different radii, overlapping
  will occur in random cases. On one hand, overlapping will reduce the calibrated number of clusters.
  On the other hand, it increases inhomogeneity even further by creating other shapes than spheres.”*
- ⇒ Gộp cụm là hiện tượng **nổi lên từ overlap**, không phải bước mô hình hoá riêng, không tune.

### 10.5 Fig. 11a / 11b

- **11a** = *“(a) Number of detections”* — **tổng điểm/frame**, 500–1.500 ở 100–130 km/h.
- **11b** = *“(b) Number of clusters”* — số **cụm**/frame.
- Caption chung: *“Comparison of simulated and measured numbers of detections and numbers of clusters
  in the spray plume from a Crafter at 50 m distance”*.

### 10.6 Hệ quả cho thiết kế tiêu chí (2026-11-11)

- **Không** dùng `mean det/cụm` làm tiêu chí: đo trên `cal` (45 frame/ô) cho `p50 = 6`,
  `mean = 43,3` (100 km/h) và **66,6 % số điểm nằm trong 5 % cụm to nhất** ⇒ mean bị đuôi chi phối.
- Tiêu chí đúng: **cụm/frame** (Bảng 1), **điểm/frame** (Bảng 1), **p50 điểm/cụm = 6**, hình học
  3 phân vị chiều cao, `p95|y|`. Chi tiết: ticket `29e-c`.

## 11. Hỏi ngày 2026-11-11 (tối) — chồng cụm và cách đặt cụm

### 11.1 Paper KHÔNG giải thích cụm lớn trong dữ liệu đo

Paper **không** có câu nào nói cụm trong dữ liệu đo chứa nhiều cụm nhỏ bị DBSCAN gộp, cũng **không**
giải thích vì sao số điểm/cụm đo được lớn hơn mô hình cầu. Paper chỉ nói dữ liệu thật không đồng nhất
(*"clusters with different shape, size and density"*). ⇒ Phần dư điểm trong dữ liệu thật là **quan sát
của mình**, không phải điều paper đã mô hình hoá.

### 11.2 Chồng cụm là hành vi ĐƯỢC PHÉP của mô hình paper

Nguyên văn:

> *"With the independent uniform placement of clusters with different radii, overlapping will occur in
> random cases. On one hand, overlapping will reduce the calibrated number of clusters. On the other
> hand, it increases inhomogeneity even further by creating other shapes than spheres. The final model
> evaluation will show that the theoretical reduction in clusters will not be significant in the end
> result, so overlapping is not prohibited in the model."*

⇒ Chồng cụm **không bị cấm**; paper chấp nhận nó và cho rằng mức giảm số cụm không đáng kể.

### 11.3 Cách đặt cụm — uniform, độc lập, giới hạn theo quỹ đạo xe

> *"To simulate clusters, spheres are positioned with a uniform distribution in the region behind every
> moving object according to the empirical values for the number of clusters and the distribution of
> cluster radii. A uniform distribution was chosen as a first estimate, as no other form of distribution
> was visible."*

> *"The initialization of clusters is restricted to the vehicle trajectory and no clusters are spawned
> randomly in the scene."*

⇒ Đặt **uniform, độc lập từng cụm**, nhưng trong **vùng sau xe** (nhỏ), không rải khắp scene.

### 11.4 Hệ quả cho 29e-d-ii

- Đo `overlap_frac` là đo **đúng đại lượng paper mô tả** (overlap do đặt uniform trong vùng hẹp).
- Nếu generator hiện có `overlap_frac` thấp hơn nhiều so với `cal`, nguyên nhân là **vùng đặt quá
  rộng** hoặc **cụm quá nhỏ so với vùng**, không phải "thiếu cơ chế gộp cụm".
- Sửa đúng hướng paper: **giữ uniform + độc lập**, chỉ thu hẹp vùng đặt cho khớp mật độ đo được.
  Không thêm bước "gom cụm theo nhóm" — paper không có bước đó.

## 12. Hỏi ngày 2026-11-12 — `P_det` hiệu chuẩn ở cự ly nào

### 12.1 Định nghĩa

> *"A beam generates only a detection in a certain cluster with a detection probability given as
> `P_det = n / n_max(r_cl, p_cl)`, (5) with the number of detections `n` in a given cluster and the
> number of beams `n_max(r_cl, p_cl)` intersecting the spherical representation of the cluster. The
> maximum number of possible detections in a spherical cluster representation depends on the cluster
> radius and the cluster position with respect to the beam pattern of the sensor."*

⇒ `P_det` là **hằng số theo cụm**, không điều chỉnh theo range. `n_max` tự giảm theo `1/d²`.

### 12.2 `P_det` và `r_cl` được hiệu chuẩn ở **25 m**, không phải 50 m

> *"probability distributions for all clusters in the spray plume with a vehicle distance of **25 m**
> are shown in Fig. 7. The variations of detection probabilities between clusters are fitted to a
> lognormal distribution."*

> *"The dashed distribution is a lognormal distribution derived as a mean from fitted distributions to
> the measurements of all velocities. The parameters of the distribution are `µ = −2.3` and `σ = 1.09`."*

⇒ Cả `r_cl` (µ = −1,2, σ = 0,8) và `P_det` (µ = −2,3, σ = 1,09) đều fit ở **25 m** `[PAPER]`.

### 12.3 Paper TỰ CẢNH BÁO mô hình cầu hỏng ở cự ly gần

> *"Moreover, with higher resolutions, a problem with the spherical cluster representation might
> appear. The problem can become especially pronounced in **close proximity to the sensor** and is to be
> evaluated in future work."*

⇒ Đây là hạn chế **paper tự thừa nhận**, chưa được giải quyết.

### 12.4 Hệ quả cho dataset SemanticSpray của mình (2026-11-12)

| | paper | dataset mình |
|---|---|---|
| cự ly hiệu chuẩn | **25 m** | 20 m và 30 m |
| phân bố điểm thật | — | **89 % điểm của Crafter@100 nằm < 15 m** |

- Dataset mình có **phần lớn điểm ở cự ly gần hơn nhiều** so với nơi paper hiệu chuẩn.
- Ở cự ly gần, `n_max` rất lớn (nhiều tia cắt cầu) nhưng thật lại có **cụm khổng lồ** do nước liền
  mảng ⇒ `P_det` đo được **> 1** ở 13–15,5 % cụm trong dải 15–40 m. Đây **chính là** hiện tượng paper
  cảnh báo: mô hình cầu không còn đúng khi gần cảm biến.
- ⇒ **Không thể** khớp điểm/frame ở dải gần bằng mô hình cầu + `P_det` hằng số. Đây là **giới hạn
  của mô hình paper**, không phải lỗi cài đặt. Phải ghi vào paper như limitation, không được tune
  tham số để che.

### 12.5 Điều chỉnh kỳ vọng cho tiêu chí A2

Tiêu chí A2 (điểm/frame = 570–1.555) đặt theo **số đo của dataset ở 20/30 m**, trong khi generator
theo mô hình paper hiệu chuẩn ở 25 m với giả thiết cầu. Hai bên đo ở điều kiện khác nhau ⇒ A2 chỉ
có thể đạt nếu thêm cơ chế ngoài paper (mảng nước liền). Quyết định: **giữ A2 làm mục tiêu chẩn
đoán, không dùng làm điều kiện chặn**, và ghi rõ trong paper là limitation có trích dẫn §12.3.

## 13. Hỏi ngày 2026-11-12 — trọng lực, `vz`, chiều cao plume

### 13.1 Paper KHÔNG có trọng lực, KHÔNG có phương trình riêng cho `z`

Chuyển động chỉ gồm **vận tốc ban đầu + drag + gió**:

> `F_D = ½ ρ_air c_D A v_rel²`
> `v_cl = ∫₀ᵗ (ρ_air c_D A / 2m)(v_w + v_cl)² dt + v₀`
> `v_cl,k = C·(v_w + v_cl,k−1)²·Δt + v_cl,k−1`, với `C = −0,15 m⁻¹`, `Δt = 100 ms`
> `p_cl,k = p_cl,k−1 + Δt·v_cl,k`

Không có số hạng `g`, không có phương trình riêng cho trục `z`.

### 13.2 Paper KHÔNG có `vz` — vận tốc ban đầu = vận tốc xe

> *"Hence, during generation of a cluster, the velocity of the moving object is set as an
> initial cluster velocity."*

⇒ `v₀` **thuần ngang**, không thành phần thẳng đứng.

### 13.3 Paper KHÔNG định nghĩa chiều cao plume

Từ *"height"* trong paper chỉ dùng cho **water film height** (độ dày màng nước) hoặc **góc elevation**
của LiDAR. Vị trí cụm đặt **uniform trong khối phía sau xe**. Cụm **không rơi**, chỉ mờ dần theo
`P_t = e^{−t/T}`.

### 13.4 Paper KHÔNG so phân bố `z` — chỉ so 3 thứ

> *"These metrics indicate that the number of detections produced by spray, distance distribution and
> inhomogeneity of the simulation are within the range of the measurements."*

Ba metric: **tổng điểm** (Fig. 11a), **phân bố theo cự ly** (Fig. 12), **số cụm** (Fig. 11b). Không có
so sánh phân bố chiều cao.

### 13.5 Hệ quả — hai sai lệch cộng dồn trong code của mình (2026-11-12)

| # | code hiện tại | paper | nhãn |
|---|---|---|---|
| 1 | `INITIAL_VZ_MAX_MPS = 5.0`, `vz ~ U(0, 5)` mỗi cụm | **không có `vz`** | `[CODE] dee.cpp:540` — **không phải paper** |
| 2 | `prune(ceilings=...)` xoá cụm vượt đỉnh box 2,62 m | **không có luật này** | `[CHỌN]` của mình, thêm để bù (1) |

Hai thứ này **bù nhau**: thêm `vz` làm cụm bay lên, rồi thêm trần để chặn. Hệ quả đo được: `T` dài ở
tốc độ cao ⇒ `vz·T` = 3,0–4,5 m > trần 2,62 m ⇒ cụm bị xoá oan ⇒ `alive/target` giảm đơn điệu
2,34 → 0,71 từ 50 → 130 km/h.

⇒ **Sửa đúng theo paper: bỏ `vz` (đặt 0) và bỏ trần.** Chiều cao plume khi đó đến thuần từ vị trí đặt
uniform trong khối 5–92 % chiều cao box, đúng như paper mô tả.

## 14. Hỏi ngày 2026-11-12 — paper khớp đến mức nào (SỐ CỤ THỂ)

### 14.1 Fig. 11a/11b — số của CHÍNH PAPER, đo vs mô phỏng (50 m, Crafter, fully covered)

| km/h | đo: cụm | đo: điểm | sim: cụm | sim: điểm | sim/đo (cụm) | sim/đo (điểm) |
|---:|---:|---:|---:|---:|---:|---:|
| 80 | 20 | 250 | 10 | 250 | **0,50** | 1,00 |
| 100 | 43 | 1.000 | 30 | 550 | **0,70** | **0,55** |
| 130 | 70 | 1.500 | 105 | 1.300 | **1,50** | 0,87 |

⇒ **Mô phỏng của paper lệch tới 2× (cụm @80) và 1,8× (điểm @100)**. Paper tự thừa nhận:

> *"The detection counts per velocity lie within the spread of the measurements. **Just at 100 and 110 km/h
> with a fully covered pavement, the simulated numbers are noticeably lower.**"*

> *"Both simulation and measurement show a similar range of cluster counts with an upwards trend over object
> speed suggesting a realistic modeling of the inhomogeneity."*

### 14.2 Điểm/cụm TĂNG theo tốc độ — paper xác nhận

Từ chính bảng 14.1 (đo): 250/20 = **12,5** @80 · 1.000/43 = **23,2** @100 · 1.500/70 = **21,4** @130.
Fig. 1 (100 km/h, 50 m): **`Mean Det./Cluster: 14.3`**, `Num. Clusters: 33`, `Clustered/Total: 84.1 %`.

⇒ Điểm/cụm **không phẳng**; tăng từ 12,5 lên ~21–23 rồi bão hoà. **PM đã sai** khi nói "thật phẳng ở 6" —
6 là **p50**, còn mean thật là 43,3 @100 → 48,6 @130 (tăng, đúng như paper).

### 14.3 Ba điểm paper tự nhận là CHƯA khớp

1. **Điểm @100–110 km/h thấp hơn thật** (550 vs 1.000 @100).
2. **Attenuation yếu ở 80–110 km/h**: *"detections in the simulation are visible at a greater distance, so
   the attenuation is not as strong as in the measurements for those speeds."*
3. **Cụm @130 km/h cao hơn thật** (105 vs 70).

### 14.4 Giới hạn paper tự nêu (Discussion §V)

- *"there is a limited amount of objects behind the spray plume"* — ít vật thể phía sau plume.
- *"the spray clusters are generated for each individual moving object… there is no interaction"*.
- *"occlusion by objects that do not generate detections themselves… is not covered"*.
- *"with higher resolutions, a problem with the spherical cluster representation might appear. The problem
  can become especially pronounced in close proximity to the sensor"*.
- *"consider only a single echo"* — bỏ qua multi-echo.

### 14.5 Kết quả A/B của paper (để so sánh với mình)

PV-RCNN, AP 0–50 m: wet road **57,97 → 75,36** (+17,4); watered road **51,34 → 59,41** (+8,1).
Voxel-RCNN: 61,04 → 61,66 (wet); 56,20 → 60,48 (watered).

### 14.6 Hệ quả cho tiêu chí của mình (2026-11-12)

- Đích đúng **không phải** "khớp thật 100 %" — paper khớp trong **spread** của đo đạc, sai số ±50 % ở
  một số mốc, và tự ghi rõ chỗ lệch.
- Tiêu chí nên đặt theo **spread**, không theo một con số: mỗi mốc tốc độ có nhiều scene, lấy khoảng
  đo được, mô phỏng nằm trong khoảng đó là đạt.
- `alive` **không phải** đại lượng so được: `P_t = exp(−age/T)` làm cụm già gần như vô hình
  (P = 1,8 % ở `age = 4T`), nên đếm cụm "còn sống" phồng lên bằng cụm không sinh được điểm.
